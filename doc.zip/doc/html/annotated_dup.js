var annotated_dup =
[
    [ "PwmPlug", "namespace_pwm_plug.html", [
      [ "PwmPlug", "class_pwm_plug_1_1_pwm_plug.html", null ]
    ] ],
    [ "Robohat", "namespace_robohat.html", [
      [ "Robohat", "class_robohat_1_1_robohat.html", "class_robohat_1_1_robohat" ]
    ] ]
];