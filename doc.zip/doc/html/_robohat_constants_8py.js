var _robohat_constants_8py =
[
    [ "ROBOHAT_BUILD_DATE_STR", "_robohat_constants_8py.html#ad710ac5c37aa87b2dc0ebf764423992f", null ],
    [ "ROBOHAT_LIB_VERSION_STR", "_robohat_constants_8py.html#a594731f97383cb0fcabea15e988e53a7", null ]
];