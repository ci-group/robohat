var searchData=
[
  ['robohat_5fbuild_5fdate_5fstr_0',['ROBOHAT_BUILD_DATE_STR',['../namespace_robohat_constants.html#ad710ac5c37aa87b2dc0ebf764423992f',1,'RobohatConstants']]],
  ['robohat_5flib_5fversion_5fstr_1',['ROBOHAT_LIB_VERSION_STR',['../namespace_robohat_constants.html#a594731f97383cb0fcabea15e988e53a7',1,'RobohatConstants']]]
];
