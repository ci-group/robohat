var searchData=
[
  ['accu_5finterval_5ftime_5fin_5fseconds_0',['ACCU_INTERVAL_TIME_IN_SECONDS',['../namespace_robohat_config.html#aa90d674eb09915b67fd60ed6054105a4',1,'RobohatConfig']]],
  ['accu_5flog_5fdisplay_5fwhen_5fto_5fhigh_1',['ACCU_LOG_DISPLAY_WHEN_TO_HIGH',['../namespace_robohat_config.html#a3012b91ef82705b1961775a6a835b28f',1,'RobohatConfig']]],
  ['accu_5flog_5fdisplay_5fwhen_5fto_5flow_2',['ACCU_LOG_DISPLAY_WHEN_TO_LOW',['../namespace_robohat_config.html#a8beb43d1452c2805453246a529ac0cfc',1,'RobohatConfig']]],
  ['accu_5fvoltage_5fadc_5fformula_5fa_3',['ACCU_VOLTAGE_ADC_FORMULA_A',['../namespace_robohat_config.html#a56df2b0bd71ca8d4b07d0e489bf25f54',1,'RobohatConfig']]],
  ['accu_5fvoltage_5fadc_5fformula_5fb_4',['ACCU_VOLTAGE_ADC_FORMULA_B',['../namespace_robohat_config.html#adb11cf7ad26b90f38ddfc944ef3b8e2b',1,'RobohatConfig']]],
  ['accu_5fvoltage_5fto_5fhigh_5fthreshold_5',['ACCU_VOLTAGE_TO_HIGH_THRESHOLD',['../namespace_robohat_config.html#a6b9c8385bb0a6ca2fbe569a77e447c04',1,'RobohatConfig']]],
  ['accu_5fvoltage_5fto_5flow_5fthreshold_6',['ACCU_VOLTAGE_TO_LOW_THRESHOLD',['../namespace_robohat_config.html#afb06ec6637d3753426359d5a296a4b03',1,'RobohatConfig']]],
  ['accu_5fvoltage_5fto_5fpercentage_5farray_7',['ACCU_VOLTAGE_TO_PERCENTAGE_ARRAY',['../namespace_robohat_config.html#a7c1d112041f80beb5b2fd35962139a3b',1,'RobohatConfig']]],
  ['accu_5fwarning_5fpercentage_5f1_8',['ACCU_WARNING_PERCENTAGE_1',['../namespace_robohat_config.html#a9ff031c125e65a4fdee84b377f9dc0f7',1,'RobohatConfig']]],
  ['accu_5fwarning_5fpercentage_5f2_9',['ACCU_WARNING_PERCENTAGE_2',['../namespace_robohat_config.html#a10a2bf7a707d26126a6111c4fae0cd47',1,'RobohatConfig']]],
  ['alarm_5fpermitted_10',['ALARM_PERMITTED',['../namespace_robohat_config.html#a921b4eee229ab6bce8264cbe1d017779',1,'RobohatConfig']]],
  ['alarm_5ftimeout_5fin_5fsec_11',['ALARM_TIMEOUT_IN_SEC',['../namespace_robohat_config.html#ada75599fe7710290d89b3c3a40a831b2',1,'RobohatConfig']]],
  ['are_5fservos_5fsleeping_12',['are_servos_sleeping',['../class_robohat_1_1_robohat.html#ac8c98160d4565f35a504dc1f1db134a6',1,'Robohat::Robohat']]]
];
