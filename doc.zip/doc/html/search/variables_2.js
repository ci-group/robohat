var searchData=
[
  ['debug_0',['DEBUG',['../namespace_robohat_config.html#a71428ec962464517de43e12e05e5a05b',1,'RobohatConfig']]],
  ['debug_5fi2c_1',['DEBUG_I2C',['../namespace_robohat_config.html#a3600bf7ade64398c502d33f992f2b0c2',1,'RobohatConfig']]]
];
