var searchData=
[
  ['scan_0',['scan',['../class_i2_c___handler_1_1_i2_c___handler.html#a150ca686d56cd02d1ec84563e6a0ed46',1,'I2C_Handler::I2C_Handler']]],
  ['scan_5fi2c_5fbus_1',['scan_i2c_bus',['../class_i_o_handler_1_1_i_o_handler.html#a866b31448d4e4a35ee142747fe3a3d16',1,'IOHandler.IOHandler.scan_i2c_bus()'],['../class_robohat_1_1_robohat.html#ab7596aa3157e74f7fdb144b03f754736',1,'Robohat.Robohat.scan_i2c_bus()']]],
  ['set_5fall_5fservos_5fangle_2',['set_all_servos_angle',['../class_servo_assembly_1_1_servo_assembly.html#afac89cc8d68a5e28576cdb67f277136a',1,'ServoAssembly::ServoAssembly']]],
  ['set_5fdutycycle_3',['set_dutycycle',['../class_g_p_o_p_w_m___l_l___driver_1_1_g_p_o_p_w_m___l_l___driver.html#a05fe7cee48e0859f3f5b2357c6011727',1,'GPOPWM_LL_Driver::GPOPWM_LL_Driver']]],
  ['set_5ffreq_4',['set_freq',['../class_g_p_o_p_w_m___l_l___driver_1_1_g_p_o_p_w_m___l_l___driver.html#ac22b0878d421065916c1114c76e66480',1,'GPOPWM_LL_Driver::GPOPWM_LL_Driver']]],
  ['set_5fhardware_5fangle_5faccording_5fto_5freadout_5fat_5finit_5',['set_hardware_angle_according_to_readout_at_init',['../class_servo_board_1_1_servo_board.html#a2790587e318aec96b5be353afe7f00f4',1,'ServoBoard::ServoBoard']]],
  ['set_5fhigh_6',['set_high',['../class_g_p_o___l_l___driver_1_1_g_p_o___l_l___driver.html#a90a869e85b351a943dcd9d72bc3be320',1,'GPO_LL_Driver::GPO_LL_Driver']]],
  ['set_5fio_5fexpander_5fdirection_7',['set_io_expander_direction',['../class_robohat_1_1_robohat.html#a44577963898eba6989e33baf9fc925fa',1,'Robohat::Robohat']]],
  ['set_5fio_5fexpander_5fouput_8',['set_io_expander_ouput',['../class_i_o_expander_1_1_i_o_expander.html#addcb0b500a06d5b3816913efba629efd',1,'IOExpander::IOExpander']]],
  ['set_5fio_5fexpander_5foutput_9',['set_io_expander_output',['../class_robohat_1_1_robohat.html#a67fb473112d51c3b0438a896596a63ad',1,'Robohat::Robohat']]],
  ['set_5fled_5fcolor_10',['set_led_color',['../class_led_multicolor_1_1_led_multicolor.html#a5aa6b81174e72c533c6df5e84a549935',1,'LedMulticolor.LedMulticolor.set_led_color()'],['../class_robohat_1_1_robohat.html#a9dd9c22a883391d5161ec5410e6e2dee',1,'Robohat.Robohat.set_led_color()']]],
  ['set_5flow_11',['set_low',['../class_g_p_o___l_l___driver_1_1_g_p_o___l_l___driver.html#a71e40ed7465a5875a5eaee4c77ca2166',1,'GPO_LL_Driver::GPO_LL_Driver']]],
  ['set_5frunning_5fparameters_12',['set_running_parameters',['../class_servo_data_1_1_servo_data.html#a355f3b3c75b8e1b00f972c1bbcff3b66',1,'ServoData::ServoData']]],
  ['set_5fservo_5fangle_13',['set_servo_angle',['../class_servo_assembly_1_1_servo_assembly.html#a536f351d9ae5c86e5b0ebfd03e9f5d6c',1,'ServoAssembly.ServoAssembly.set_servo_angle()'],['../class_robohat_1_1_robohat.html#a7a43b9392a7bfc72fd7e5557428ecbfa',1,'Robohat.Robohat.set_servo_angle(self, int _servo_nr, float _angle)']]],
  ['set_5fservos_5fangles_14',['set_servos_angles',['../class_robohat_1_1_robohat.html#a8502d86fe4e75c63b5cfb6dd1e5dbc6f',1,'Robohat::Robohat']]],
  ['set_5fsetting_5fdo_5fpwm_5faccording_5fto_5freadout_5fat_5finit_15',['set_setting_do_pwm_according_to_readout_at_init',['../class_servo_assembly_1_1_servo_assembly.html#ab9c2a74fe11cdbba07b71bdcaddc1f76',1,'ServoAssembly::ServoAssembly']]],
  ['set_5fstatus_16',['set_status',['../class_g_p_o___l_l___driver_1_1_g_p_o___l_l___driver.html#a128081dac3ac0d7f570a88be67d78f0c',1,'GPO_LL_Driver::GPO_LL_Driver']]],
  ['set_5fstatus_5fled_17',['set_status_led',['../class_led__driver_1_1_led__driver.html#a5d0b7d42bf2942db6fdfefd9f85dec80',1,'Led_driver::Led_driver']]],
  ['signal_5fsystem_5falarm_18',['signal_system_alarm',['../class_buzzer_1_1_buzzer.html#a6da90ea433fe13e51c27f36f4f6fb7ae',1,'Buzzer::Buzzer']]],
  ['sleep_19',['sleep',['../class_p_c_a9685_1_1_p_c_a9685.html#a2bbc475f3481e2547d2cab53f8b70743',1,'PCA9685::PCA9685']]]
];
