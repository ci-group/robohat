var searchData=
[
  ['init_0',['init',['../class_robohat_1_1_robohat.html#a726c77fb9ff04911df0ea9a5e9a80d57',1,'Robohat::Robohat']]]
];
