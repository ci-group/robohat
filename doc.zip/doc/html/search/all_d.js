var searchData=
[
  ['wakeup_5fservo_0',['wakeup_servo',['../class_robohat_1_1_robohat.html#afc25fb6e247cd612021d47779b45d0b4',1,'Robohat::Robohat']]]
];
