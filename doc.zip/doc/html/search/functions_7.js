var searchData=
[
  ['servo_5fset_5fnew_5freadout_5fvs_5fangle_5fformula_0',['servo_set_new_readout_vs_angle_formula',['../class_robohat_1_1_robohat.html#a746e3572f420c0177505e7fc5e4a0135',1,'Robohat::Robohat']]],
  ['set_5fassemblyboard_5f1_5fio_5fexpander_5fint_5fcallback_1',['set_assemblyboard_1_io_expander_int_callback',['../class_robohat_1_1_robohat.html#a230d9f644b146dbe5f5abc46f39d8c49',1,'Robohat::Robohat']]],
  ['set_5fassemblyboard_5f2_5fio_5fexpander_5fint_5fcallback_2',['set_assemblyboard_2_io_expander_int_callback',['../class_robohat_1_1_robohat.html#af2a7507e7b00cadb3814aebb1390a364',1,'Robohat::Robohat']]],
  ['set_5fled_5fcolor_3',['set_led_color',['../class_robohat_1_1_robohat.html#a9dd9c22a883391d5161ec5410e6e2dee',1,'Robohat::Robohat']]],
  ['set_5fservo_5fdirect_5fmode_4',['set_servo_direct_mode',['../class_robohat_1_1_robohat.html#a05309a6b93a91d76aef587a011bf7a26',1,'Robohat::Robohat']]],
  ['set_5fservo_5fio_5fexpander_5fdirection_5',['set_servo_io_expander_direction',['../class_robohat_1_1_robohat.html#af0a169d7d39ecc886e115631c46b8136',1,'Robohat::Robohat']]],
  ['set_5fservo_5fio_5fexpander_5foutput_6',['set_servo_io_expander_output',['../class_robohat_1_1_robohat.html#ad1c22ced463dc58d46a482bd44f7eddf',1,'Robohat::Robohat']]],
  ['set_5fservo_5fmultiple_5fangles_7',['set_servo_multiple_angles',['../class_robohat_1_1_robohat.html#a3541b58433580865b5459ec412a11c81',1,'Robohat::Robohat']]],
  ['set_5fservo_5fsingle_5fangle_8',['set_servo_single_angle',['../class_robohat_1_1_robohat.html#ab45b37a6bde413f1a5fd8afb8253cb54',1,'Robohat::Robohat']]],
  ['set_5fsystem_5falarm_5fpermitted_9',['set_system_alarm_permitted',['../class_robohat_1_1_robohat.html#a253bf0810db96c57b56935c97a68aa51',1,'Robohat::Robohat']]],
  ['set_5ftopboard_5fio_5fexpander_5fdirection_10',['set_topboard_io_expander_direction',['../class_robohat_1_1_robohat.html#a90c0b9397755090e60c167a3c06a9e43',1,'Robohat::Robohat']]],
  ['set_5ftopboard_5fio_5fexpander_5fint_5fcallback_11',['set_topboard_io_expander_int_callback',['../class_robohat_1_1_robohat.html#a9721285fe6aa3e4cdc8c543643ba3319',1,'Robohat::Robohat']]],
  ['set_5ftopboard_5fio_5fexpander_5fint_5frelease_5ffunction_12',['set_topboard_io_expander_int_release_function',['../class_robohat_1_1_robohat.html#a12cf31b3bd0cffc75de029c94e6985d1',1,'Robohat::Robohat']]],
  ['set_5ftopboard_5fio_5fexpander_5foutput_13',['set_topboard_io_expander_output',['../class_robohat_1_1_robohat.html#a90b3164ba85f9da0bdf34e3df35cecf1',1,'Robohat::Robohat']]]
];
